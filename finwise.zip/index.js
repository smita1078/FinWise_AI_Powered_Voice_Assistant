const mysql = require('mysql2/promise');

// MySQL Config
const dbConfig = {
  host: '104.154.108.125',
  user: 'finwise-user',
  password: 'n7(SSVz:u?:J>83M',
  database: 'finwise-db',
};

exports.logTopicSelection = async (req, res) => {
  try {
    const params = req.body.sessionInfo?.parameters ?? {};
    const sessionId = req.body.sessionInfo?.session ?? null;
    const callerNumber = params["telephony-caller-id"] ?? null;
    const userLang = params.user_language ?? 'en';

    // All possible language-specific menu choices
    const engChoice = params.english_menu_choice ?? null;
    const hinChoice = params.hindi_menu_choice ?? null;
    const gerChoice = params.german_menu_choice ?? null;
    const marChoice = params.marathi_menu_choice ?? null;

    const customQuery = params.custom_query?.trim() ?? null;

    console.log('Received parameters:', JSON.stringify(params, null, 2));

    // Common topic map across all languages
    const topicMap = {
      '1': 'Banking Basics',
      '2': 'Investment Knowledge and Stock Market',
      '3': 'Government Scheme',
      '5': 'NGO Help', // ✅ Added
    };

    // Language-specific mapping
    let selectedTopic = 'unknown';
    switch (userLang) {
      case 'en':
        selectedTopic = topicMap[engChoice] ?? 'unknown';
        break;
      case 'hi':
        selectedTopic = topicMap[hinChoice] ?? 'unknown';
        break;
      case 'de':
        selectedTopic = topicMap[gerChoice] ?? 'unknown';
        break;
      case 'mr':
        selectedTopic = topicMap[marChoice] ?? 'unknown';
        break;
      default:
        selectedTopic = 'unknown';
    }

    const conn = await mysql.createConnection(dbConfig);
    await conn.execute(
      `INSERT INTO session_topic_log 
       (session_id, caller_number, language_selected, topic_selected, custom_query)
       VALUES (?, ?, ?, ?, ?)`,
      [sessionId, callerNumber, userLang, selectedTopic, customQuery]
    );
    await conn.end();

    return res.json({}); // Silent response for IVR

  } catch (err) {
    console.error('Unhandled error:', err);
    return res.json({
      fulfillment_response: {
        messages: [
          { text: { text: ['Something went wrong while logging your selection.'] } }
        ]
      }
    });
  }
};
