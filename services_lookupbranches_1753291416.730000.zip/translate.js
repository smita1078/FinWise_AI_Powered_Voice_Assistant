const { TranslationServiceClient } = require('@google-cloud/translate').v3;

// Initialize Translation API client
const client = new TranslationServiceClient();

const PROJECT_ID = 'bankonvoicebot';  // ✅ Replace with your actual GCP project ID
const LOCATION = 'global';

/**
 * Translates text to the target language using Google Cloud Translation API.
 * Skips translation if language is English.
 *
 * @param {string} text - Text to translate
 * @param {string} targetLang - Target language code (e.g., 'hi' for Hindi, 'en' for English)
 * @returns {Promise<string>} Translated text or original text on failure
 */
exports.translateText = async (text, targetLang) => {
  if (!text || typeof text !== 'string') return '';
  if (!targetLang || targetLang === 'en') return text;

  try {
    const request = {
      parent: `projects/${PROJECT_ID}/locations/${LOCATION}`,
      contents: [text],
      mimeType: 'text/plain',
      targetLanguageCode: targetLang,
    };

    const [response] = await client.translateText(request);
    return response.translations?.[0]?.translatedText || text;
  } catch (err) {
    console.error('❌ Translation error:', err.message || err);
    return text; // fallback to original text if translation fails
  }
};
