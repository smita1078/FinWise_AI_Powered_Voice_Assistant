const fs = require('fs');
const path = require('path');
const csv = require('csv-parser');

// Optional: useful if you want to log the city corresponding to pincode
function findCityByPincode(pincode) {
  return new Promise((resolve, reject) => {
    const filePath = path.join(__dirname, '../pincode-to-city.csv');
    let cityFound = null;

    fs.createReadStream(filePath)
      .pipe(csv())
      .on('data', (row) => {
        const pinFromRow = String(row['pincode'] || row[1]).trim();
        if (pinFromRow === pincode) {
          const city = row['Taluk'] || row['Districtname'] || '';
          if (city) cityFound = city.trim();
        }
      })
      .on('end', () => resolve(cityFound))
      .on('error', reject);
  });
}

module.exports = { findCityByPincode };
