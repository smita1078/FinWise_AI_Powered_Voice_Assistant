const fs = require('fs');
const path = require('path');
const csv = require('csv-parser');
const xlsx = require('xlsx');

// Utility to sanitize text
function sanitizeText(text) {
  return (text || '')
    .toString()
    .replace(/[\\'"`]/g, '')
    .trim();
}

// Sanitize each row's keys and values
function sanitizeRow(row) {
  const sanitized = {};
  for (const key in row) {
    sanitized[sanitizeText(key)] = sanitizeText(row[key]);
  }
  return sanitized;
}

// Load CSV or XLSX for the given bank key
function loadBankCSV(bankKey) {
  return new Promise((resolve, reject) => {
    const basePath = path.join(__dirname, '../bank-data');
    const csvPath = path.join(basePath, `${bankKey}.csv`);
    const xlsxPath = path.join(basePath, `${bankKey}.xlsx`);

    if (fs.existsSync(xlsxPath)) {
      console.log(`📘 Reading XLSX file for bank: ${bankKey}`);
      try {
        const workbook = xlsx.readFile(xlsxPath);
        const sheet = workbook.Sheets[workbook.SheetNames[0]];
        const rawData = xlsx.utils.sheet_to_json(sheet);
        const data = rawData.map(sanitizeRow);
        console.log(`✅ Loaded ${data.length} rows from ${bankKey}.xlsx`);
        return resolve(data);
      } catch (err) {
        console.error(`❌ Failed to read XLSX: ${err.message}`);
        return reject(err);
      }
    }

    if (fs.existsSync(csvPath)) {
      console.log(`📘 Reading CSV file for bank: ${bankKey}`);
      const results = [];
      fs.createReadStream(csvPath)
        .pipe(csv())
        .on('data', (row) => results.push(sanitizeRow(row)))
        .on('end', () => {
          console.log(`✅ Loaded ${results.length} rows from ${bankKey}.csv`);
          resolve(results);
        })
        .on('error', (err) => {
          console.error(`❌ Failed to read CSV: ${err.message}`);
          reject(err);
        });
    } else {
      console.warn(`⚠️ No file found for bank: ${bankKey} (.csv or .xlsx)`);
      resolve([]);
    }
  });
}

module.exports = { loadBankCSV };
