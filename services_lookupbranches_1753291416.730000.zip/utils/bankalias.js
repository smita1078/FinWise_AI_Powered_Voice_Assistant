const stringSimilarity = require('string-similarity');

// Map of aliases → canonical keys used in filenames like SBI.xlsx
const bankAliasMap = {
  'UNION BANK OF INDIA': 'UNION',
  'YES BANK': 'YES',
  'UCO BANK': 'UCO',
  'STATE BANK OF INDIA': 'SBI',
  'STATE BANK': 'SBI',
  'RESERVE BANK OF INDIA': 'RBI',
  'PUNJAB NATIONAL BANK': 'PNB',
  'JPMORGAN CHASE': 'JPM',
  'IDBI BANK': 'IDBI',
  'HSBC BANK': 'HSBC',
  'HDFC BANK': 'HDFC',
  'DEUTSCHE BANK': 'DB',
  'CENTRAL BANK OF INDIA': 'CBI',
  'CITI BANK': 'CITI',
  'CITIBANK': 'CITI',
  'BARCLAYS BANK': 'BARCLAYS',
  'BANK OF BARODA': 'BOB',
  'AXIS BANK': 'AXIS',
  // Short aliases
  'UNION': 'UNION',
  'YES': 'YES',
  'UCO': 'UCO',
  'SBI': 'SBI',
  'RBI': 'RBI',
  'PNB': 'PNB',
  'JPM': 'JPM',
  'IDBI': 'IDBI',
  'HSBC': 'HSBC',
  'HDFC': 'HDFC',
  'DB': 'DB',
  'CBI': 'CBI',
  'CITI': 'CITI',
  'BOB': 'BOB',
  'AXIS': 'AXIS',
};

// Cleans input and handles common transcription issues
function cleanInput(text) {
  return (text || '')
    .toString()
    .toUpperCase()
    .replace(/[^A-Z ]/g, '') // remove punctuation/symbols
    .replace(/\s+/g, ' ')    // normalize spacing
    .trim();
}

// Main function to match alias
function getBankKey(inputBankName) {
  if (!inputBankName) return null;

  const cleaned = cleanInput(inputBankName);
  if (bankAliasMap[cleaned]) {
    console.log(`✅ Direct alias match: "${cleaned}" → ${bankAliasMap[cleaned]}`);
    return bankAliasMap[cleaned];
  }

  const bankNames = Object.keys(bankAliasMap);
  const bestMatch = stringSimilarity.findBestMatch(cleaned, bankNames).bestMatch;

  if (bestMatch.rating > 0.6) {
    console.log(`🔍 Fuzzy match: "${cleaned}" ≈ "${bestMatch.target}" → ${bankAliasMap[bestMatch.target]}`);
    return bankAliasMap[bestMatch.target];
  }

  console.warn(`❌ No valid bank match for input: "${inputBankName}"`);
  return null;
}

module.exports = { bankAliasMap, getBankKey };
