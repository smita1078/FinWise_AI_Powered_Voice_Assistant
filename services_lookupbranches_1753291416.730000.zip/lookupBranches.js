const { loadBankCSV } = require('./utils/loadCSV');
const { getBankKey } = require('./utils/bankalias');
const { translateText } = require('./translate');
const stringSimilarity = require('string-similarity');

// Hindi number words
const hindiNumbers = {
  '0': 'शून्य', '1': 'एक', '2': 'दो', '3': 'तीन', '4': 'चार',
  '5': 'पांच', '6': 'छह', '7': 'सात', '8': 'आठ', '9': 'नौ',
};

// English number words
const englishNumbers = {
  '0': 'zero', '1': 'one', '2': 'two', '3': 'three', '4': 'four',
  '5': 'five', '6': 'six', '7': 'seven', '8': 'eight', '9': 'nine',
};

// Clean symbols, quotes, whitespace
function sanitizeText(text) {
  return (text || '').toString().replace(/[\\'"`.,]/g, '').trim().toLowerCase();
}

// Convert digits to spoken words
function convertNumberToWords(numStr, lang) {
  const map = lang === 'hi' ? hindiNumbers : englishNumbers;
  return numStr.split('').map(d => map[d] || d).join(' ');
}

// Replace pincode in address with spoken version
function replacePincodeInAddress(address, lang) {
  return address.replace(/\b\d{6}\b/g, match => convertNumberToWords(match, lang));
}

// Translate with fallback
async function safeTranslate(text, lang) {
  if (lang === 'en') return text;
  try {
    const translated = await translateText(text, lang);
    return translated || text;
  } catch (err) {
    console.warn('⚠️ Translation failed:', err);
    return text;
  }
}

exports.lookupBranches = async (req, res) => {
  try {
    const params = req.body.sessionInfo?.parameters ?? {};
    let rawBankInput = (params.bank_name || '').toString().trim();
    const userLang = params.user_language || 'en';
    const pincodeRaw = params.pincode;

    // Normalize pincode
    const pincode = typeof pincodeRaw === 'string'
      ? pincodeRaw.trim()
      : typeof pincodeRaw === 'number'
        ? String(pincodeRaw)
        : Array.isArray(pincodeRaw)
          ? String(pincodeRaw[0]).trim()
          : '';

    console.log('🔍 Received Request:', { rawBankInput, pincode, userLang });

    // Clean spoken bank input (remove trailing dot, noise)
    rawBankInput = sanitizeText(rawBankInput);

    if (!rawBankInput || !/^\d{6}$/.test(pincode)) {
      const msg = await safeTranslate('Please provide a valid bank name and a 6-digit pincode.', userLang);
      return res.json({ fulfillment_response: { messages: [{ text: { text: [msg] } }] } });
    }

    // Get canonical bank key via alias + fuzzy match
    const bankKey = getBankKey(rawBankInput);
    if (!bankKey) {
      const msg = await safeTranslate(`Sorry, we don't support "${rawBankInput}". Please try another bank.`, userLang);
      return res.json({ fulfillment_response: { messages: [{ text: { text: [msg] } }] } });
    }

    console.log(`📘 Reading XLSX file for bank: ${bankKey}`);
    const branches = await loadBankCSV(bankKey);

    // Match branches using fuzzy match or substring
    const matched = branches.filter(branch => {
      const address = sanitizeText(branch.ADDRESS || '').replace(/\s+/g, '');
      return address.includes(pincode) ||
        stringSimilarity.compareTwoStrings(address, pincode) > 0.6;
    });

    console.log(`✅ Matches found for ${bankKey} in pincode ${pincode}: ${matched.length}`);

    const pincodeSpoken = convertNumberToWords(pincode, userLang);
    let reply = '';

    if (matched.length > 0) {
      const branch = matched[0];
      const branchName = sanitizeText(branch.BRANCH);
      const address = sanitizeText(branch.ADDRESS);
      const addressSpoken = replacePincodeInAddress(address, userLang);
      const indexStr = convertNumberToWords('1', userLang);

      reply = `${bankKey} branch with pincode ${pincodeSpoken}:\n${indexStr}. ${branchName}, ${addressSpoken}`;
    } else {
      reply = `Sorry, no ${bankKey} branches found with pincode ${pincodeSpoken}.`;
    }

    const translated = await safeTranslate(reply, userLang);

    console.log('🗣 Final reply:', translated);
    return res.json({
      fulfillment_response: {
        messages: [{ text: { text: [translated] } }]
      }
    });

  } catch (err) {
    console.error('❌ Unexpected error:', err);
    const fallbackMsg = await safeTranslate('An error occurred while fetching branch details.', 'en');
    return res.json({
      fulfillment_response: {
        messages: [{ text: { text: [fallbackMsg] } }]
      }
    });
  }
};
