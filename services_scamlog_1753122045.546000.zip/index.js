const mysql = require('mysql2/promise');

const dbConfig = {
  host: '104.154.108.125',
  user: 'finwise-user',
  password: 'n7(SSVz:u?:J>83M',
  database: 'finwise-db',
};

exports.logScamReport = async (req, res) => {
  try {
    const body = req.body;

    // Check if coming from Dialogflow CX or tool call
    const isDialogflow = !!body.sessionInfo;

    const parameters = isDialogflow ? body.sessionInfo.parameters || {} : body;
    const sessionId = isDialogflow
      ? body.sessionInfo.session || 'unknown_session'
      : body.session_id || 'unknown_session';

    const scamType = parameters.scam_type || 'Unknown';
    const riskLevel = parameters.risk_level || 'Unknown';

    const connection = await mysql.createConnection(dbConfig);

    const insertQuery = `
      INSERT INTO scam_reports (session_id, scam_type, risk_level)
      VALUES (?, ?, ?)
    `;

    await connection.execute(insertQuery, [sessionId, scamType, riskLevel]);
    await connection.end();

    // Tool response
    if (!isDialogflow) {
      return res.status(200).json({ success: true, message: 'Scam report logged successfully.' });
    }

    // Dialogflow response
    res.json({
      fulfillment_response: {
        messages: [{ text: { text: ['Scam report logged successfully.'] } }],
      },
    });
  } catch (error) {
    console.error('DB insert failed:', error);

    // Tool error response
    if (!req.body.sessionInfo) {
      return res.status(500).json({ success: false, message: 'Failed to log scam report.' });
    }

    // Dialogflow error response
    res.json({
      fulfillment_response: {
        messages: [{ text: { text: ['Failed to log scam report.'] } }],
      },
    });
  }
};
